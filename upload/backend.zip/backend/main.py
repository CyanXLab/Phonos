"""
Phonos 口语练习平台 - FastAPI 后端
"""

import os
import sys
import traceback
import tempfile
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from phoneme_data import (
    PRESET_SENTENCES, WORD_DICT, PHONEME_TIPS, MINIMAL_PAIRS,
    ARPABET_TO_IPA, VOCAB,
)
from g2p_service import get_g2p_service, G2PService
from onnx_service import get_recognizer
from scoring import evaluate_pronunciation, generate_error_tips, result_to_dict

app = FastAPI(title="Phonos 口语练习平台", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 模型路径：优先读环境变量，否则在项目根目录的 model/ 子目录中查找
_SCRIPT_DIR = Path(__file__).resolve().parent
_PROJECT_ROOT = _SCRIPT_DIR.parent

def _find_model() -> str:
    """自动查找 ONNX 模型文件"""
    env_path = os.environ.get("HUPER_MODEL_PATH", "")
    if env_path and os.path.isfile(env_path):
        return env_path

    # 按优先级搜索
    search_paths = [
        _PROJECT_ROOT / "models" / "model.onnx",
        _PROJECT_ROOT / "models" / "model_quantized.onnx",
        _SCRIPT_DIR / "models" / "model.onnx",
        _SCRIPT_DIR / "models" / "model_quantized.onnx",
        _PROJECT_ROOT / "huper_onnx" / "model.onnx",
        _PROJECT_ROOT / "huper_onnx_int8_dynamic" / "model_quantized.onnx",
    ]
    for p in search_paths:
        if p.is_file():
            return str(p)

    return ""

MODEL_PATH = _find_model()
_phoneme_cache: dict = {}


@app.on_event("startup")
async def startup():
    print("[启动] 初始化 Phonons 口语练习平台...")
    g2p = get_g2p_service()
    print(f"[启动] G2P 服务就绪 (g2p_en: {'可用' if g2p.available else '不可用，使用词典'})")

    for sentence in PRESET_SENTENCES:
        text = sentence["text"]
        if text not in _phoneme_cache:
            phonemes = g2p.text_to_phonemes(text)
            word_phonemes = g2p.text_to_phonemes_with_words(text)
            ipa = g2p.arpabet_to_ipa(phonemes)
            _phoneme_cache[text] = {
                "phonemes": phonemes,
                "word_phonemes": word_phonemes,
                "ipa": ipa,
            }
            print(f"  预计算: '{text}' -> {' '.join(phonemes)}")

    if MODEL_PATH and os.path.exists(MODEL_PATH):
        try:
            get_recognizer(MODEL_PATH)
            print(f"[启动] ONNX 模型加载成功: {MODEL_PATH}")
        except Exception as e:
            print(f"[启动] ONNX 模型加载失败: {e}")
    else:
        print("[启动] ⚠️  未找到 ONNX 模型，请将模型文件放到以下位置之一:")
        print(f"         - {_PROJECT_ROOT / 'model' / 'model.onnx'}")
        print(f"         - {_PROJECT_ROOT / 'model' / 'model_quantized.onnx'}")
        print("         或设置环境变量 HUPER_MODEL_PATH 指定模型路径")

    print("[启动] 平台初始化完成")


# ============================================================
# API 路由
# ============================================================

@app.get("/api/health")
async def health_check():
    model_ok = MODEL_PATH != "" and os.path.exists(MODEL_PATH)
    try:
        get_recognizer()
        model_loaded = True
    except:
        model_loaded = False
    return {
        "status": "ok",
        "model_loaded": model_loaded or model_ok,
        "g2p_available": get_g2p_service().available,
    }


@app.get("/api/sentence")
async def get_random_sentence():
    """获取随机练习句子（含翻译、词组、单词详情）"""
    import random
    sentence = random.choice(PRESET_SENTENCES)
    return _enrich_sentence(sentence)


@app.get("/api/sentences")
async def get_all_sentences():
    """获取所有练习句子"""
    return [_enrich_sentence(s) for s in PRESET_SENTENCES]


@app.get("/api/sentence/{sentence_id}")
async def get_sentence_by_id(sentence_id: int):
    """按ID获取句子"""
    for s in PRESET_SENTENCES:
        if s["id"] == sentence_id:
            return _enrich_sentence(s)
    raise HTTPException(status_code=404, detail="句子不存在")


@app.get("/api/minimal-pairs")
async def get_minimal_pairs():
    """获取最小对立对数据"""
    return MINIMAL_PAIRS


@app.get("/api/phoneme-tips")
async def get_phoneme_tips():
    """获取全部44个音素的发音指南"""
    result = {}
    for phoneme, info in PHONEME_TIPS.items():
        result[phoneme] = {
            "description": info["description"],
            "ipa": info.get("ipa", ARPABET_TO_IPA.get(phoneme, "")),
            "common_error": info["common_error"],
            "solution": info["solution"],
            "mouth_shape": info["mouth_shape"],
            "practice_words": info.get("practice_words", []),
        }
    return result


@app.post("/api/evaluate")
async def evaluate_audio(
    audio: UploadFile = File(...),
    sentence_text: str = Form(...),
):
    """评测音频发音"""
    try:
        g2p = get_g2p_service()
        expected_phonemes = g2p.text_to_phonemes(sentence_text)
        word_phonemes = g2p.text_to_phonemes_with_words(sentence_text)

        if not expected_phonemes:
            raise HTTPException(status_code=400, detail="无法生成期望音素序列")

        suffix = Path(audio.filename or "audio.wav").suffix
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            content = await audio.read()
            tmp.write(content)
            tmp_path = tmp.name

        try:
            import soundfile as sf
            import librosa

            audio_data, sr = sf.read(tmp_path)
            if sr != 16000:
                audio_data = librosa.resample(audio_data, orig_sr=sr, target_sr=16000)
                sr = 16000
            if audio_data.ndim > 1:
                audio_data = audio_data.mean(axis=-1)
            audio_float = audio_data.astype(np.float32)

            recognizer = get_recognizer(MODEL_PATH)
            result_dict = recognizer.recognize_with_timestamps(audio_float, sr)
            actual_phonemes = result_dict["phonemes"]
            timeline = result_dict["timeline"]
            blank_segments = result_dict["blank_segments"]
            total_duration = result_dict["total_duration"]

            eval_result = evaluate_pronunciation(
                expected_phonemes=expected_phonemes,
                actual_phonemes=actual_phonemes,
                word_boundaries=word_phonemes,
                timeline=timeline,
                blank_segments=blank_segments,
                total_duration=total_duration,
            )

            tips = generate_error_tips(eval_result.errors)
            response = result_to_dict(eval_result, tips)
            response["sentence"] = sentence_text

            # 添加单词详情
            words = sentence_text.lower().split()
            response["word_details"] = [_get_word_detail(w) for w in words]

            return response
        finally:
            os.unlink(tmp_path)

    except HTTPException:
        raise
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"评测失败: {str(e)}")


# ============================================================
# 辅助函数
# ============================================================

def _enrich_sentence(sentence: dict) -> dict:
    """为句子数据添加音素和单词详情"""
    text = sentence["text"]
    cached = _phoneme_cache.get(text, {})

    words = text.lower().split()
    word_details = [_get_word_detail(w) for w in words]

    return {
        "id": sentence["id"],
        "text": text,
        "translation": sentence.get("translation", ""),
        "difficulty": sentence["difficulty"],
        "category": sentence["category"],
        "tags": sentence.get("tags", []),
        "key_phrases": sentence.get("key_phrases", []),
        "cultural_note": sentence.get("cultural_note", ""),
        "phonemes": cached.get("phonemes", []),
        "ipa": cached.get("ipa", ""),
        "word_phonemes": cached.get("word_phonemes", []),
        "word_details": word_details,
    }


def _get_word_detail(word: str) -> dict:
    """获取单词详情"""
    info = WORD_DICT.get(word, {})
    g2p = get_g2p_service()
    arpabet = info.get("arpabet", g2p.text_to_phonemes(word))
    ipa = G2PService.arpabet_to_ipa(arpabet) if arpabet else ""

    return {
        "word": word,
        "pos": info.get("pos", ""),
        "meaning": info.get("meaning", ""),
        "ipa": info.get("ipa", ipa),
        "arpabet": arpabet,
        "example": info.get("example", ""),
        "frequency": info.get("frequency", 0),
        "difficulty": info.get("difficulty", 0),
        "memory_tip": info.get("memory_tip", ""),
        "grammar_note": info.get("grammar_note", ""),
    }


# 挂载前端
frontend_path = Path(__file__).parent.parent / "frontend"
if frontend_path.exists():
    app.mount("/", StaticFiles(directory=str(frontend_path), html=True), name="frontend")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
