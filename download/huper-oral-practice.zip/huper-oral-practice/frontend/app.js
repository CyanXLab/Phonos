/**
 * HuPER 口语练习平台 - 前端逻辑
 *
 * 功能：
 * 1. 获取/切换练习句子
 * 2. 录音 + 波形可视化
 * 3. 上传音频 + 评测
 * 4. 展示评测结果（评分、音素对比、错误诊断、建议）
 */

const API_BASE = '';  // 同源部署

// ============================================================
// 状态管理
// ============================================================
const state = {
    currentSentence: null,
    isRecording: false,
    mediaRecorder: null,
    audioContext: null,
    analyser: null,
    mediaStream: null,
    audioChunks: [],
    recordingStartTime: 0,
    recordingTimer: null,
    animationFrame: null,
};

// ============================================================
// DOM 引用
// ============================================================
const $ = id => document.getElementById(id);

const els = {
    modelStatus: $('modelStatus'),
    sentenceText: $('sentenceText'),
    difficultyTag: $('difficultyTag'),
    phonemePreview: $('phonemePreview'),
    btnRefresh: $('btnRefresh'),
    btnRecord: $('btnRecord'),
    recordIcon: $('recordIcon'),
    recordLabel: $('recordLabel'),
    recordingInfo: $('recordingInfo'),
    recordingTime: $('recordingTime'),
    waveformCanvas: $('waveformCanvas'),
    waveformOverlay: $('waveformOverlay'),
    resultCard: $('resultCard'),
    loadingCard: $('loadingCard'),
    overallScore: $('overallScore'),
    scoreRing: $('scoreRing'),
    pronScore: $('pronScore'),
    compScore: $('compScore'),
    fluScore: $('fluScore'),
    pronFill: $('pronFill'),
    compFill: $('compFill'),
    fluFill: $('fluFill'),
    expectedChips: $('expectedChips'),
    actualChips: $('actualChips'),
    wordScoreList: $('wordScoreList'),
    statDuration: $('statDuration'),
    statRate: $('statRate'),
    statPauses: $('statPauses'),
    statPauseDur: $('statPauseDur'),
    tipsList: $('tipsList'),
    btnRetry: $('btnRetry'),
    btnNextSentence: $('btnNextSentence'),
};

// ============================================================
// 初始化
// ============================================================
async function init() {
    await loadSentence();
    initWaveformCanvas();
    bindEvents();
    checkHealth();
}

async function checkHealth() {
    try {
        const res = await fetch(`${API_BASE}/api/health`);
        const data = await res.json();
        els.modelStatus.textContent = data.model_loaded ? '模型已就绪' : '演示模式';
        els.modelStatus.className = 'badge ' + (data.model_loaded ? 'online' : '');
    } catch {
        els.modelStatus.textContent = '离线';
        els.modelStatus.className = 'badge';
    }
}

// ============================================================
// 句子加载
// ============================================================
async function loadSentence() {
    try {
        const res = await fetch(`${API_BASE}/api/sentence`);
        const data = await res.json();
        state.currentSentence = data;
        renderSentence(data);
    } catch (err) {
        console.error('加载句子失败:', err);
        els.sentenceText.textContent = '加载失败，请刷新页面重试';
    }
}

function renderSentence(data) {
    els.sentenceText.textContent = data.text;
    els.difficultyTag.textContent = data.difficulty;
    els.difficultyTag.className = 'difficulty-tag ' + data.difficulty;
    els.phonemePreview.textContent = data.phonemes ? data.phonemes.join(' ') : '';

    // 隐藏结果
    els.resultCard.style.display = 'none';
    els.loadingCard.style.display = 'none';
}

// ============================================================
// 事件绑定
// ============================================================
function bindEvents() {
    els.btnRefresh.addEventListener('click', loadSentence);
    els.btnRecord.addEventListener('click', toggleRecording);
    els.btnRetry.addEventListener('click', () => {
        els.resultCard.style.display = 'none';
    });
    els.btnNextSentence.addEventListener('click', loadSentence);
}

// ============================================================
// 录音功能
// ============================================================
async function toggleRecording() {
    if (state.isRecording) {
        stopRecording();
    } else {
        await startRecording();
    }
}

async function startRecording() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({
            audio: {
                channelCount: 1,
                sampleRate: 16000,
                echoCancellation: true,
                noiseSuppression: true,
            }
        });

        state.mediaStream = stream;
        state.audioChunks = [];
        state.isRecording = true;

        // 创建 AudioContext 用于波形可视化
        state.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const source = state.audioContext.createMediaStreamSource(stream);
        state.analyser = state.audioContext.createAnalyser();
        state.analyser.fftSize = 2048;
        source.connect(state.analyser);

        // 创建 MediaRecorder
        state.mediaRecorder = new MediaRecorder(stream, {
            mimeType: getSupportedMimeType(),
        });

        state.mediaRecorder.ondataavailable = (e) => {
            if (e.data.size > 0) {
                state.audioChunks.push(e.data);
            }
        };

        state.mediaRecorder.onstop = () => {
            handleRecordingComplete();
        };

        state.mediaRecorder.start(100); // 每100ms收集一次数据

        // UI 更新
        updateRecordingUI(true);
        startWaveformAnimation();
        startRecordingTimer();

    } catch (err) {
        console.error('录音启动失败:', err);
        alert('无法访问麦克风，请确保已授予麦克风权限。');
    }
}

function stopRecording() {
    state.isRecording = false;

    if (state.mediaRecorder && state.mediaRecorder.state !== 'inactive') {
        state.mediaRecorder.stop();
    }

    if (state.mediaStream) {
        state.mediaStream.getTracks().forEach(t => t.stop());
    }

    if (state.audioContext) {
        state.audioContext.close();
    }

    // UI 更新
    updateRecordingUI(false);
    stopWaveformAnimation();
    stopRecordingTimer();
}

function updateRecordingUI(recording) {
    const inner = els.btnRecord.querySelector('.record-inner');
    if (recording) {
        inner.classList.add('recording');
        els.recordIcon.classList.add('stop');
        els.recordLabel.textContent = '点击停止';
        els.recordingInfo.style.display = 'flex';
        els.waveformOverlay.classList.add('hidden');
    } else {
        inner.classList.remove('recording');
        els.recordIcon.classList.remove('stop');
        els.recordLabel.textContent = '点击录音';
        els.recordingInfo.style.display = 'none';
    }
}

function startRecordingTimer() {
    state.recordingStartTime = Date.now();
    state.recordingTimer = setInterval(() => {
        const elapsed = Math.floor((Date.now() - state.recordingStartTime) / 1000);
        const min = String(Math.floor(elapsed / 60)).padStart(2, '0');
        const sec = String(elapsed % 60).padStart(2, '0');
        els.recordingTime.textContent = `${min}:${sec}`;
    }, 200);
}

function stopRecordingTimer() {
    if (state.recordingTimer) {
        clearInterval(state.recordingTimer);
        state.recordingTimer = null;
    }
}

function getSupportedMimeType() {
    const types = [
        'audio/webm;codecs=opus',
        'audio/webm',
        'audio/ogg;codecs=opus',
        'audio/mp4',
        'audio/wav',
    ];
    for (const type of types) {
        if (MediaRecorder.isTypeSupported(type)) {
            return type;
        }
    }
    return '';
}

// ============================================================
// 波形可视化
// ============================================================
function initWaveformCanvas() {
    const canvas = els.waveformCanvas;
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);

    // 绘制默认静态波形
    drawIdleWaveform(ctx, rect.width, rect.height);
}

function drawIdleWaveform(ctx, w, h) {
    ctx.clearRect(0, 0, w, h);

    const centerY = h / 2;
    ctx.beginPath();
    ctx.strokeStyle = '#c7d2fe';
    ctx.lineWidth = 2;

    for (let x = 0; x < w; x++) {
        const y = centerY + Math.sin(x * 0.03) * 3;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    }
    ctx.stroke();
}

function startWaveformAnimation() {
    const canvas = els.waveformCanvas;
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    const w = rect.width;
    const h = rect.height;
    const ctx = canvas.getContext('2d');

    const bufferLength = state.analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    function draw() {
        state.analyser.getByteTimeDomainData(dataArray);

        ctx.clearRect(0, 0, w, h);

        // 背景渐变
        const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
        bgGrad.addColorStop(0, 'rgba(79, 110, 247, 0.03)');
        bgGrad.addColorStop(1, 'rgba(79, 110, 247, 0.08)');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, w, h);

        // 波形
        ctx.lineWidth = 2.5;
        ctx.strokeStyle = '#4f6ef7';
        ctx.beginPath();

        const sliceWidth = w / bufferLength;
        let x = 0;

        for (let i = 0; i < bufferLength; i++) {
            const v = dataArray[i] / 128.0;
            const y = v * (h / 2);

            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);

            x += sliceWidth;
        }

        ctx.lineTo(w, h / 2);
        ctx.stroke();

        // 频率柱状图（底部）
        const freqData = new Uint8Array(state.analyser.frequencyBinCount);
        state.analyser.getByteFrequencyData(freqData);

        const barCount = 40;
        const barWidth = w / barCount - 2;
        const step = Math.floor(freqData.length / barCount);

        for (let i = 0; i < barCount; i++) {
            const value = freqData[i * step] / 255;
            const barHeight = value * h * 0.3;
            const alpha = 0.3 + value * 0.5;

            ctx.fillStyle = `rgba(79, 110, 247, ${alpha})`;
            ctx.fillRect(
                i * (barWidth + 2),
                h - barHeight,
                barWidth,
                barHeight
            );
        }

        state.animationFrame = requestAnimationFrame(draw);
    }

    draw();
}

function stopWaveformAnimation() {
    if (state.animationFrame) {
        cancelAnimationFrame(state.animationFrame);
        state.animationFrame = null;
    }

    // 重绘静态波形
    const canvas = els.waveformCanvas;
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(dpr, dpr);
    drawIdleWaveform(ctx, rect.width, rect.height);
}

// ============================================================
// 录音完成 & 评测
// ============================================================
async function handleRecordingComplete() {
    const mimeType = state.mediaRecorder?.mimeType || 'audio/webm';
    const blob = new Blob(state.audioChunks, { type: mimeType });

    // 最短录音检查
    if (blob.size < 1000) {
        alert('录音时间太短，请重试。');
        return;
    }

    // 显示加载
    els.loadingCard.style.display = 'flex';
    els.resultCard.style.display = 'none';

    try {
        const formData = new FormData();
        const ext = mimeType.includes('webm') ? 'webm' : mimeType.includes('ogg') ? 'ogg' : 'wav';
        formData.append('audio', blob, `recording.${ext}`);
        formData.append('sentence_text', state.currentSentence.text);

        let data;
        try {
            const res = await fetch(`${API_BASE}/api/evaluate`, {
                method: 'POST',
                body: formData,
            });
            if (!res.ok) throw new Error('评测请求失败');
            data = await res.json();
        } catch (err) {
            // 尝试演示模式
            console.warn('正式评测失败，尝试演示模式:', err);
            const demoForm = new FormData();
            demoForm.append('sentence_text', state.currentSentence.text);
            const demoRes = await fetch(`${API_BASE}/api/evaluate/demo`, {
                method: 'POST',
                body: demoForm,
            });
            data = await demoRes.json();
        }

        renderResults(data);

    } catch (err) {
        console.error('评测失败:', err);
        alert('评测失败: ' + err.message);
    } finally {
        els.loadingCard.style.display = 'none';
    }
}

// ============================================================
// 结果渲染
// ============================================================
function renderResults(data) {
    els.resultCard.style.display = 'block';

    // 1. 总分动画
    const overall = data.scores.overall;
    animateScore(els.overallScore, overall);
    animateScoreRing(overall);

    // 2. 分项评分
    animateSubScore(els.pronScore, els.pronFill, data.scores.pronunciation);
    animateSubScore(els.compScore, els.compFill, data.scores.completeness);
    animateSubScore(els.fluScore, els.fluFill, data.scores.fluency);

    // 3. 音素对比
    renderPhonemeCompare(data);

    // 4. 单词评分
    renderWordScores(data);

    // 5. 流利度详情
    renderFluencyDetails(data);

    // 6. 发音建议
    renderTips(data);

    // 滚动到结果
    setTimeout(() => {
        els.resultCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 300);
}

function animateScore(element, target) {
    let current = 0;
    const duration = 1200;
    const start = performance.now();

    function step(timestamp) {
        const progress = Math.min((timestamp - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3); // easeOutCubic
        current = Math.round(eased * target);
        element.textContent = current;

        if (progress < 1) {
            requestAnimationFrame(step);
        }
    }

    requestAnimationFrame(step);
}

function animateScoreRing(score) {
    const circumference = 326.73;
    const offset = circumference * (1 - score / 100);
    els.scoreRing.style.transition = 'stroke-dashoffset 1.2s cubic-bezier(0.4, 0, 0.2, 1)';
    els.scoreRing.style.strokeDashoffset = offset;

    // 颜色
    let color = '#4f6ef7';
    if (score >= 80) color = '#22c55e';
    else if (score >= 60) color = '#4f6ef7';
    else if (score >= 40) color = '#f59e0b';
    else color = '#ef4444';
    els.scoreRing.style.stroke = color;
}

function animateSubScore(scoreEl, fillEl, value) {
    animateScore(scoreEl, value);
    setTimeout(() => {
        fillEl.style.width = value + '%';
    }, 100);
}

function renderPhonemeCompare(data) {
    const expected = data.phonemes.expected;
    const actual = data.phonemes.actual;
    const errors = data.errors;

    // 构建错误映射
    const errorPositions = new Map();
    errors.forEach(err => {
        if (err.type === 'substitution') {
            errorPositions.set(err.position, { type: 'sub', actual: err.actual, expected: err.expected });
        } else if (err.type === 'deletion') {
            errorPositions.set(err.position, { type: 'del', expected: err.expected });
        }
    });

    // 期望音素
    els.expectedChips.innerHTML = '';
    expected.forEach((p, i) => {
        const chip = document.createElement('span');
        chip.className = 'phoneme-chip';
        if (errorPositions.has(i)) {
            chip.classList.add('wrong');
        } else {
            chip.classList.add('correct');
        }
        chip.textContent = p;
        els.expectedChips.appendChild(chip);
    });

    // 实际音素
    els.actualChips.innerHTML = '';
    const actualSet = new Set(actual);

    // 简单显示实际识别的音素
    actual.forEach((p, i) => {
        const chip = document.createElement('span');
        chip.className = 'phoneme-chip';
        // 检查是否在期望中
        if (expected.includes(p)) {
            chip.classList.add('correct');
        } else {
            chip.classList.add('extra');
        }
        chip.textContent = p;
        els.actualChips.appendChild(chip);
    });
}

function renderWordScores(data) {
    els.wordScoreList.innerHTML = '';

    data.words.forEach(w => {
        const item = document.createElement('div');
        item.className = 'word-score-item' + (w.has_error ? ' error' : '');

        const accClass = w.accuracy >= 80 ? 'high' : w.accuracy >= 50 ? 'medium' : 'low';

        item.innerHTML = `
            <span class="word-score-word">${w.word}</span>
            <span class="word-score-acc ${accClass}">${w.accuracy}%</span>
        `;
        els.wordScoreList.appendChild(item);
    });
}

function renderFluencyDetails(data) {
    const fd = data.fluency_details;
    els.statDuration.textContent = fd.total_duration + 's';
    els.statRate.textContent = fd.speaking_rate + ' 音素/秒';
    els.statPauses.textContent = fd.pause_count;
    els.statPauseDur.textContent = fd.pause_duration + 's';
}

function renderTips(data) {
    els.tipsList.innerHTML = '';

    if (!data.tips || data.tips.length === 0) {
        els.tipsList.innerHTML = '<div class="tip-item severity-low"><p class="tip-description">🎉 发音很好！没有发现明显问题。</p></div>';
        return;
    }

    data.tips.forEach(tip => {
        const item = document.createElement('div');
        item.className = `tip-item severity-${tip.severity}`;

        let typeLabel = '';
        if (tip.type === 'substitution') typeLabel = '错读';
        else if (tip.type === 'deletion') typeLabel = '漏读';
        else if (tip.type === 'insertion') typeLabel = '多读';

        let detailHTML = '';

        if (tip.type === 'insertion') {
            detailHTML = `<p>${tip.tip}</p>`;
        } else {
            detailHTML = `
                ${tip.common_error ? `<p><strong>常见错误：</strong>${tip.common_error}</p>` : ''}
                ${tip.solution ? `<p><strong>纠正方法：</strong>${tip.solution}</p>` : ''}
                ${tip.mouth_shape ? `<p><strong>口型要点：</strong>${tip.mouth_shape}</p>` : ''}
            `;
        }

        item.innerHTML = `
            <div class="tip-header">
                <span class="tip-type">${typeLabel}</span>
                <span class="tip-description">${tip.description}</span>
            </div>
            <div class="tip-detail">
                ${detailHTML}
            </div>
        `;

        els.tipsList.appendChild(item);
    });
}

// ============================================================
// 启动
// ============================================================
document.addEventListener('DOMContentLoaded', init);

// 窗口大小变化时重新初始化 canvas
window.addEventListener('resize', () => {
    initWaveformCanvas();
});
