"""
HuPER 口语练习平台 - FastAPI 后端

API 接口：
  GET  /api/sentence       - 获取随机练习句子
  GET  /api/sentences      - 获取所有句子
  POST /api/evaluate        - 上传音频并评测发音
  GET  /api/health          - 健康检查
"""

import os
import sys
import json
import tempfile
import traceback
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
import numpy as np

# 添加当前目录到 path
sys.path.insert(0, str(Path(__file__).parent))

from phoneme_data import PRESET_SENTENCES, PHONEME_TIPS
from g2p_service import get_g2p_service
from onnx_service import get_recognizer, HuPERRecognizer
from scoring import (
    evaluate_pronunciation,
    generate_error_tips,
    result_to_dict,
    EvaluationResult,
)

app = FastAPI(
    title="HuPER 口语练习平台",
    description="基于 HuPER ONNX 模型的英语发音评测 API",
    version="1.0.0",
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 模型路径（可通过环境变量配置）
MODEL_PATH = os.environ.get("HUPER_MODEL_PATH", "")

# 预计算音素缓存
_phoneme_cache: dict = {}


@app.on_event("startup")
async def startup():
    """启动时初始化模型"""
    print("[启动] 初始化 HuPER 口语练习平台...")

    # 初始化 G2P 服务
    g2p = get_g2p_service()
    print(f"[启动] G2P 服务就绪 (g2p_en: {'可用' if g2p.available else '不可用，使用词典'})")

    # 预计算所有句子的音素
    for sentence in PRESET_SENTENCES:
        text = sentence["text"]
        if text not in _phoneme_cache:
            phonemes = g2p.text_to_phonemes(text)
            word_phonemes = g2p.text_to_phonemes_with_words(text)
            _phoneme_cache[text] = {
                "phonemes": phonemes,
                "word_phonemes": word_phonemes,
            }
            print(f"  预计算: '{text}' -> {phonemes}")

    # 加载 ONNX 模型（如果路径存在）
    if MODEL_PATH and os.path.exists(MODEL_PATH):
        try:
            get_recognizer(MODEL_PATH)
            print(f"[启动] ONNX 模型加载成功: {MODEL_PATH}")
        except Exception as e:
            print(f"[启动] ONNX 模型加载失败: {e}")
            print("[启动] 将在首次评测时尝试加载模型")
    else:
        print(f"[启动] 未配置模型路径 (HUPER_MODEL_PATH)，将在评测时尝试加载")

    print("[启动] 平台初始化完成")


# ============================================================
# API 路由
# ============================================================

@app.get("/api/health")
async def health_check():
    """健康检查"""
    return {
        "status": "ok",
        "model_loaded": MODEL_PATH != "" and os.path.exists(MODEL_PATH),
        "g2p_available": get_g2p_service().available,
    }


@app.get("/api/sentence")
async def get_random_sentence():
    """获取随机练习句子"""
    import random
    sentence = random.choice(PRESET_SENTENCES)
    text = sentence["text"]

    # 获取预计算的音素
    cached = _phoneme_cache.get(text, {})
    phonemes = cached.get("phonemes", [])
    word_phonemes = cached.get("word_phonemes", [])

    return {
        "id": sentence["id"],
        "text": text,
        "difficulty": sentence["difficulty"],
        "category": sentence["category"],
        "phonemes": phonemes,
        "word_phonemes": word_phonemes,
    }


@app.get("/api/sentences")
async def get_all_sentences():
    """获取所有练习句子"""
    result = []
    for sentence in PRESET_SENTENCES:
        text = sentence["text"]
        cached = _phoneme_cache.get(text, {})
        result.append({
            "id": sentence["id"],
            "text": text,
            "difficulty": sentence["difficulty"],
            "category": sentence["category"],
            "phonemes": cached.get("phonemes", []),
            "word_phonemes": cached.get("word_phonemes", []),
        })
    return result


@app.post("/api/evaluate")
async def evaluate_audio(
    audio: UploadFile = File(...),
    sentence_text: str = Form(...),
):
    """
    评测音频发音

    参数:
        audio: 上传的音频文件 (wav/mp3/webm)
        sentence_text: 练习句子文本

    返回:
        评测结果（评分、错误诊断、建议）
    """
    try:
        # 1. 获取期望音素
        g2p = get_g2p_service()
        expected_phonemes = g2p.text_to_phonemes(sentence_text)
        word_phonemes = g2p.text_to_phonemes_with_words(sentence_text)

        if not expected_phonemes:
            raise HTTPException(status_code=400, detail="无法生成期望音素序列")

        # 2. 保存上传的音频到临时文件
        suffix = Path(audio.filename or "audio.wav").suffix
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            content = await audio.read()
            tmp.write(content)
            tmp_path = tmp.name

        try:
            # 3. 加载音频
            import soundfile as sf
            import librosa

            audio_data, sr = sf.read(tmp_path)

            # 重采样到 16kHz
            if sr != 16000:
                audio_data = librosa.resample(audio_data, orig_sr=sr, target_sr=16000)
                sr = 16000

            # 单声道
            if audio_data.ndim > 1:
                audio_data = audio_data.mean(axis=-1)

            audio_float = audio_data.astype(np.float32)

            # 4. ONNX 推理
            recognizer = get_recognizer(MODEL_PATH)

            # 带时间戳的识别
            result_dict = recognizer.recognize_with_timestamps(audio_float, sr)
            actual_phonemes = result_dict["phonemes"]
            timeline = result_dict["timeline"]
            blank_segments = result_dict["blank_segments"]
            total_duration = result_dict["total_duration"]

            # 5. 发音评测
            eval_result = evaluate_pronunciation(
                expected_phonemes=expected_phonemes,
                actual_phonemes=actual_phonemes,
                word_boundaries=word_phonemes,
                timeline=timeline,
                blank_segments=blank_segments,
                total_duration=total_duration,
            )

            # 6. 生成建议
            tips = generate_error_tips(eval_result.errors)

            # 7. 格式化输出
            response = result_to_dict(eval_result, tips)
            response["sentence"] = sentence_text

            return response

        finally:
            # 清理临时文件
            os.unlink(tmp_path)

    except HTTPException:
        raise
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"评测失败: {str(e)}")


@app.post("/api/evaluate/demo")
async def evaluate_demo(sentence_text: str = Form(...)):
    """
    演示评测（无需音频，模拟结果）
    用于在没有 ONNX 模型时测试前端
    """
    import random

    g2p = get_g2p_service()
    expected_phonemes = g2p.text_to_phonemes(sentence_text)
    word_phonemes = g2p.text_to_phonemes_with_words(sentence_text)

    # 模拟：随机替换几个音素
    actual_phonemes = list(expected_phonemes)
    num_errors = max(1, len(expected_phonemes) // 5)
    error_indices = random.sample(range(len(expected_phonemes)), min(num_errors, len(expected_phonemes)))

    # 常见替换映射
    common_subs = {
        "TH": "S", "DH": "Z", "V": "W", "L": "R", "R": "L",
        "IH": "IY", "EH": "AE", "AE": "AH", "S": "Z", "Z": "S",
    }

    for idx in error_indices:
        p = expected_phonemes[idx]
        if p in common_subs:
            actual_phonemes[idx] = common_subs[p]

    # 评测
    eval_result = evaluate_pronunciation(
        expected_phonemes=expected_phonemes,
        actual_phonemes=actual_phonemes,
        word_boundaries=word_phonemes,
        timeline=[],
        blank_segments=[],
        total_duration=3.0,
    )

    tips = generate_error_tips(eval_result.errors)
    response = result_to_dict(eval_result, tips)
    response["sentence"] = sentence_text
    response["demo"] = True

    return response


# 挂载前端静态文件
frontend_path = Path(__file__).parent.parent / "frontend"
if frontend_path.exists():
    app.mount("/", StaticFiles(directory=str(frontend_path), html=True), name="frontend")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
